<?php $__env->startSection('title', 'Laravel Framework – Lab 6'); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Laravel Framework – Bài thực hành']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Laravel Framework – Bài thực hành']); ?>
    <p>Ứng dụng minh họa routing, controller, Blade, Eloquent và migration.</p>
    <ul>
        <li><a href="<?php echo e(route('students.static')); ?>">Danh sách sinh viên tĩnh</a></li>
        <li><a href="<?php echo e(route('students.db')); ?>">Danh sách sinh viên từ cơ sở dữ liệu</a></li>
        <li><a href="<?php echo e(route('students.create')); ?>">Tạo sinh viên mới</a></li>
        <li><a href="<?php echo e(route('students.combined', ['source' => 'array'])); ?>">So sánh nguồn dữ liệu</a></li>
        <li><a href="<?php echo e(route('about')); ?>">Giới thiệu học phần</a></li>
    </ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/home.blade.php ENDPATH**/ ?>
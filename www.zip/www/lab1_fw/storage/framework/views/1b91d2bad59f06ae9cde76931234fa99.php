<?php $__env->startSection('title','Danh sách sinh viên (DB)'); ?>

<?php $__env->startSection('content'); ?>
<h2>Danh sách sinh viên – Nguồn: CSDL (Eloquent)</h2>

<?php if(session('success')): ?>
  <p role="status"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Lọc và quản lý sinh viên']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Lọc và quản lý sinh viên']); ?>
  <form method="get" action="<?php echo e(route('students.db')); ?>" style="margin-bottom:12px">
    <label for="gender">Lọc giới tính:</label>
    <select id="gender" name="gender" onchange="this.form.submit()">
      <option value="" <?php if(empty($gender)): echo 'selected'; endif; ?>>Tất cả</option>
      <option value="male" <?php if(($gender ?? '') === 'male'): echo 'selected'; endif; ?>>Nam</option>
      <option value="female" <?php if(($gender ?? '') === 'female'): echo 'selected'; endif; ?>>Nữ</option>
    </select>
  </form>
  <a href="<?php echo e(route('students.create')); ?>">Tạo sinh viên mới</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

<table>
  <thead>
    <tr>
      <th>STT</th>
      <th>Họ tên</th>
      <th>Tuổi</th>
      <th>Giới tính</th>
      <th>Email</th>
      <th>Lớp</th>
      <th>Nhãn tuổi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($loop->iteration + ($students->currentPage()-1)*$students->perPage()); ?></td>
        <td><?php echo e($s->name); ?></td>
        <td class="<?php echo \Illuminate\Support\Arr::toCssClasses(['adult' => ($s->age ?? 0) >= 18]); ?>"><?php echo e($s->age); ?></td>
        <td><?php echo e($s->gender); ?></td>
        <td><?php echo e($s->email); ?></td>
        <td><?php echo e($s->class_name); ?></td>
        <td><?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['age' => $s->age]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['age' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s->age)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div style="margin-top:12px">
  <?php echo e($students->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/students/index_db.blade.php ENDPATH**/ ?>
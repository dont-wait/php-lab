<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title','Lab 01'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      table { border-collapse: collapse; width: 100%; }
      th, td { border: 1px solid #ddd; padding: 8px; }
      th { background: #f3f4f6; text-align: left; }
      .adult { font-weight: 600; }
    </style>
</head>
<body>
<header>
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</header>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer>
    <hr>
    <small>&copy; HUIT – Khoa CNTT</small>
</footer>
</body>
</html>
<?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/layouts/app.blade.php ENDPATH**/ ?>
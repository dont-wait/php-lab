<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['age' => 0]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['age' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php ($isAdult = (int) $age >= 18); ?>

<span style="padding:2px 8px; border-radius:10px; font-size:12px; background:<?php echo e($isAdult ? '#DCFCE7' : '#FEE2E2'); ?>; color:<?php echo e($isAdult ? '#166534' : '#7F1D1D'); ?>;">
    <?php echo e($isAdult ? 'Adult (≥18)' : 'Under 18'); ?>

</span>
<?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/components/badge.blade.php ENDPATH**/ ?>
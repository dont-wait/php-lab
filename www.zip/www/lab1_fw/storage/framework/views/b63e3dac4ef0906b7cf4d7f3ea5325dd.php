<h1>Laravel – Lab 6</h1>
<nav aria-label="Điều hướng chính">
    <a href="<?php echo e(route('home')); ?>">Trang chủ</a> |
    <a href="<?php echo e(url('/hello')); ?>">Hello</a> |
    <a href="<?php echo e(route('students.static')); ?>">Sinh viên tĩnh</a> |
    <a href="<?php echo e(route('students.db')); ?>">Sinh viên CSDL</a> |
    <a href="<?php echo e(url('/time')); ?>">Thời gian</a> |
    <a href="<?php echo e(route('about')); ?>">Giới thiệu</a>
</nav>
<hr>
<?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/partials/header.blade.php ENDPATH**/ ?>
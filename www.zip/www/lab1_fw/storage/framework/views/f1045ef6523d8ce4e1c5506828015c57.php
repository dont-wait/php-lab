<?php $__env->startSection('title','Danh sách sinh viên (Mảng)'); ?>

<?php $__env->startSection('content'); ?>
<h2>Danh sách sinh viên – Nguồn: Mảng tĩnh</h2>
<p>Đang hiển thị <?php echo e(count($students)); ?> sinh viên từ mảng tĩnh.</p>
<nav aria-label="Nguồn dữ liệu">
  <a href="<?php echo e(route('students.static')); ?>" aria-current="page">Tĩnh (Array)</a> |
  <a href="<?php echo e(route('students.combined', ['source' => 'db'])); ?>">CSDL (Eloquent)</a>
</nav>

<table>
  <thead>
    <tr>
      <th>STT</th>
      <th>Họ tên</th>
      <th>Tuổi</th>
      <th>Giới tính</th>
      <th>Email</th>
      <th>Lớp</th>
      <th>Nhãn tuổi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($s['name']); ?></td>
           <td class="<?php echo \Illuminate\Support\Arr::toCssClasses(['adult' => ($s['age'] ?? 0) >= 18]); ?>"><?php echo e($s['age']); ?></td>
        <td><?php echo e($s['gender']); ?></td>
        <td><?php echo e($s['email']); ?></td>
        <td><?php echo e($s['class_name']); ?></td>
        <td><?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['age' => $s['age']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['age' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s['age'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dontwait/Documents/git/php-labs/lab5/lab1_fw/resources/views/students/index.blade.php ENDPATH**/ ?>